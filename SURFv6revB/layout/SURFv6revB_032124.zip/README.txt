This design is intended to follow the Bitelle 8-layer stackup from here:

https://www.7pcb.com/Upload_file/Multi-layer-stack-up.pdf

layer 1
2x1080 prepreg (5.9 mils)
layer 2
core (9 mils)
layer 3
7628 prepreg (7.3 mils)
layer 4
core (5.1 mils)
layer 5
7628 prepreg (7.3 mils)
layer 6
core (9 mils)
layer 7
2x1080 prepreg (5.9 mils)
layer 8

Please contact allison.122@osu.edu if this stackup is no longer possible.

art001.pho: Top Copper
art002.pho : Inner Layer 2
art003.pho : Inner Layer 3
art004.pho : Inner Layer 4
art005.pho : Inner Layer 5
art006.pho : Inner Layer 6
art007.pho : Inner Layer 7
art008.pho : Bottom Copper
sm001121.pho : Top Soldermask
sm008128.pho : Bottom Soldermask
sst001126.pho : Top Silkscreen
ssb008129.pho : Bottom Silkscreen
smd001123.pho : Top Paste Mask
smd008122.pho : Bottom Paste Mask
drl001.drl : NC Drill
